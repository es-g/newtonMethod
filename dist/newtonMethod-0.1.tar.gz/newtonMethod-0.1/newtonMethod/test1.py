from newton import Newton

f = '2*x**2 - 50'
newton = Newton(f)

newton.find_solution(1)
